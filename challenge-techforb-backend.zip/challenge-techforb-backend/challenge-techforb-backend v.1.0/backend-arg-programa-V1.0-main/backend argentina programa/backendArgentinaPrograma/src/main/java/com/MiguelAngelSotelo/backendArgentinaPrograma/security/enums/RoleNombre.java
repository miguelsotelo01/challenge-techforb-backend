package com.MiguelAngelSotelo.backendArgentinaPrograma.security.enums;

public enum RoleNombre {
    ROLE_ADMIN, ROLE_USER
}
